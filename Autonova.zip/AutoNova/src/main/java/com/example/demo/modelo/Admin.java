package com.example.demo.modelo;

public class Admin {

}
