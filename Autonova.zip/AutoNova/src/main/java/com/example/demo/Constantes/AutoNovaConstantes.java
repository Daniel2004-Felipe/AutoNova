package com.example.demo.Constantes;

public class AutoNovaConstantes {

	
	public static final String ALGO_SALIO_MAL= "Algo salio mal";
	
	public static final String Datos_Incorrectos= "Datos incorrectos";
}
